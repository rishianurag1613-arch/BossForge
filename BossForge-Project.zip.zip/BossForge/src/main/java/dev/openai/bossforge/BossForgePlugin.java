package dev.openai.bossforge;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Villager;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.world.ChunkLoadEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

/**
 * BossForge: globally one-time boss egg crafting and peaceful supply challenges.
 * Guardians are invulnerable, non-hostile villagers. Players contribute supplies;
 * the leading contributor receives a commemorative relic (not a weapon).
 */
public final class BossForgePlugin extends JavaPlugin implements Listener, CommandExecutor {
    private static final int MIN_PROTOCOL = 774; // Minecraft Java 1.21.11
    private static final int[] INPUT_SLOTS = {10, 11, 12, 19, 20, 21, 28, 29, 30};
    private static final int OUTPUT_SLOT = 25;

    private NamespacedKey eggKey, forgeKey, bossKey, progressKey, topContributorKey, topContributionKey;
    private final Map<UUID, BossBar> activeBars = new HashMap<>();


    private enum Tier {
        WOOD("wood", "Grove Guardian", "Grove Crest", Material.OAK_LOG, 48, Material.AMETHYST_SHARD, BarColor.GREEN, Villager.Profession.FARMER),
        STONE("stone", "Granite Golem", "Stone Seal", Material.COBBLESTONE, 48, Material.PRISMARINE_SHARD, BarColor.WHITE, Villager.Profession.MASON),
        COPPER("copper", "Storm Sentinel", "Copper Medallion", Material.COPPER_INGOT, 32, Material.COPPER_INGOT, BarColor.YELLOW, Villager.Profession.ARMORER),
        IRON("iron", "Iron Warden", "Iron Emblem", Material.IRON_INGOT, 32, Material.IRON_INGOT, BarColor.WHITE, Villager.Profession.TOOLSMITH),
        GOLD("gold", "Sunforged Champion", "Golden Sigil", Material.GOLD_INGOT, 24, Material.GOLD_INGOT, BarColor.YELLOW, Villager.Profession.CLERIC),
        DIAMOND("diamond", "Crystal Colossus", "Diamond Star", Material.DIAMOND, 12, Material.DIAMOND, BarColor.BLUE, Villager.Profession.LIBRARIAN),
        NETHERITE("netherite", "Nether Tyrant", "Ancient Crown", Material.NETHERITE_SCRAP, 6, Material.NETHERITE_INGOT, BarColor.PURPLE, Villager.Profession.SHEPHERD);

        final String id, bossName, relicName;
        final Material supply, relicMaterial;
        final int required;
        final BarColor barColor;
        final Villager.Profession profession;
        Tier(String id, String bossName, String relicName, Material supply, int required,
             Material relicMaterial, BarColor barColor, Villager.Profession profession) {
            this.id = id; this.bossName = bossName; this.relicName = relicName; this.supply = supply;
            this.required = required; this.relicMaterial = relicMaterial; this.barColor = barColor; this.profession = profession;
        }
        static Tier fromId(String id) {
            for (Tier tier : values()) if (tier.id.equalsIgnoreCase(id) || tier.name().equalsIgnoreCase(id)) return tier;
            return null;
        }
    }

    private record Ingredient(Material material) {
        static Ingredient of(Material material) { return new Ingredient(material); }
        boolean matches(ItemStack stack) {
            return stack != null && stack.getType() == material && stack.getAmount() >= 1;
        }
    }

    private static final class ForgeHolder implements InventoryHolder {
        private Inventory inventory;
        @Override public Inventory getInventory() { return inventory; }
    }

    @Override
    public void onEnable() {
        eggKey = new NamespacedKey(this, "boss_egg");
        forgeKey = new NamespacedKey(this, "boss_forge");
        bossKey = new NamespacedKey(this, "boss_event_tier");
        progressKey = new NamespacedKey(this, "boss_event_progress");
        topContributorKey = new NamespacedKey(this, "boss_event_top_player");
        topContributionKey = new NamespacedKey(this, "boss_event_top_amount");
        saveDefaultConfig();
        Bukkit.getPluginManager().registerEvents(this, this);
        if (getCommand("bossforge") != null) getCommand("bossforge").setExecutor(this);
        registerForgeRecipe();
        rebuildActiveEvents();
        getLogger().info("BossForge enabled. ViaVersion per-client version checks: "
                + (Bukkit.getPluginManager().isPluginEnabled("ViaVersion") ? "enabled" : "not available"));
    }

    @Override
    public void onDisable() {
        for (BossBar bar : activeBars.values()) bar.removeAll();
        activeBars.clear();
    }

    private void rebuildActiveEvents() {
        for (World world : Bukkit.getWorlds()) for (Entity entity : world.getEntities()) {
            if (!(entity instanceof Villager villager)) continue;
            Tier tier = Tier.fromId(villager.getPersistentDataContainer().get(bossKey, PersistentDataType.STRING));
            if (tier == null) continue;
            int progress = villager.getPersistentDataContainer().getOrDefault(progressKey, PersistentDataType.INTEGER, 0);
            BossBar bar = createBossBar(tier, progress);
            activeBars.put(villager.getUniqueId(), bar);
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (supportsCustomFeatures(player)) bar.addPlayer(player); else player.hideEntity(this, villager);
            }
        }
    }

    private BossBar createBossBar(Tier tier, int progress) {
        BossBar bar = Bukkit.createBossBar(tier.bossName + " — supplies " + progress + "/" + tier.required,
                tier.barColor, BarStyle.SOLID);
        bar.setProgress(Math.max(0, Math.min(1, progress / (double) tier.required)));
        return bar;
    }

    private ItemStack makeItem(Material material, String name, List<String> lore, NamespacedKey key, String value) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.GOLD + "" + ChatColor.BOLD + name);
        if (lore != null) meta.setLore(lore);
        if (key != null && value != null) meta.getPersistentDataContainer().set(key, PersistentDataType.STRING, value);
        item.setItemMeta(meta);
        return item;
    }


    private void registerForgeRecipe() {
        NamespacedKey recipeKey = new NamespacedKey(this, "boss_forge_recipe");
        Bukkit.removeRecipe(recipeKey);
        ShapedRecipe recipe = new ShapedRecipe(recipeKey, forgeItem());
        recipe.shape("ODO", "ICI", "ODO");
        recipe.setIngredient('O', Material.OBSIDIAN);
        recipe.setIngredient('D', Material.DIAMOND);
        recipe.setIngredient('I', Material.IRON_INGOT);
        recipe.setIngredient('C', Material.CRAFTING_TABLE);
        Bukkit.addRecipe(recipe);
    }

    private ItemStack forgeItem() {
        ItemStack item = makeItem(Material.SMITHING_TABLE, "Boss Forge", List.of(
                ChatColor.GRAY + "Place this block and right-click it.",
                ChatColor.YELLOW + "Used for the seven one-time boss egg recipes.",
                ChatColor.DARK_GRAY + "BossForge"), forgeKey, "boss_forge");
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey(this, "boss_forge"));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack eggItem(Tier tier) {
        ItemStack item = makeItem(Material.EGG, tier.bossName + " Egg", List.of(
                ChatColor.GRAY + "Right-click a block to start a peaceful supply challenge.",
                ChatColor.YELLOW + "Bring " + tier.required + " " + pretty(tier.supply) + ".",
                ChatColor.AQUA + "Minecraft Java 1.21.11+ feature"), eggKey, tier.id);
        ItemMeta meta = item.getItemMeta();
        meta.setItemModel(new NamespacedKey(this, tier.id + "_boss_egg"));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack relicItem(Tier tier) {
        return makeItem(tier.relicMaterial, tier.relicName, List.of(
                ChatColor.GRAY + "Commemorative reward for completing the " + tier.bossName + " challenge.",
                ChatColor.LIGHT_PURPLE + "Top contributor reward", ChatColor.DARK_GRAY + "BossForge"), null, null);
    }

    private Ingredient[] recipeFor(Tier tier) {
        // These are the exact survival recipes shown in the second BossForge recipe poster.
        // The centre ingredient is always one ordinary chicken egg.
        return switch (tier) {
            case WOOD -> new Ingredient[]{
                    Ingredient.of(Material.OAK_LOG), Ingredient.of(Material.OAK_PLANKS), Ingredient.of(Material.OAK_LOG),
                    Ingredient.of(Material.OAK_PLANKS), Ingredient.of(Material.EGG), Ingredient.of(Material.OAK_PLANKS),
                    Ingredient.of(Material.OAK_LOG), Ingredient.of(Material.OAK_PLANKS), Ingredient.of(Material.OAK_LOG)};
            case STONE -> new Ingredient[]{
                    Ingredient.of(Material.COBBLESTONE), Ingredient.of(Material.COBBLESTONE), Ingredient.of(Material.COBBLESTONE),
                    Ingredient.of(Material.COBBLESTONE), Ingredient.of(Material.EGG), Ingredient.of(Material.COBBLESTONE),
                    Ingredient.of(Material.COBBLESTONE), Ingredient.of(Material.COBBLESTONE), Ingredient.of(Material.COBBLESTONE)};
            case COPPER -> new Ingredient[]{
                    Ingredient.of(Material.COPPER_INGOT), Ingredient.of(Material.COPPER_BLOCK), Ingredient.of(Material.COPPER_INGOT),
                    Ingredient.of(Material.COPPER_INGOT), Ingredient.of(Material.EGG), Ingredient.of(Material.COPPER_BLOCK),
                    Ingredient.of(Material.COPPER_INGOT), Ingredient.of(Material.COPPER_BLOCK), Ingredient.of(Material.COPPER_BLOCK)};
            case IRON -> new Ingredient[]{
                    Ingredient.of(Material.IRON_INGOT), Ingredient.of(Material.IRON_INGOT), Ingredient.of(Material.IRON_INGOT),
                    Ingredient.of(Material.IRON_INGOT), Ingredient.of(Material.EGG), Ingredient.of(Material.IRON_INGOT),
                    Ingredient.of(Material.IRON_INGOT), Ingredient.of(Material.IRON_INGOT), Ingredient.of(Material.IRON_INGOT)};
            case GOLD -> new Ingredient[]{
                    Ingredient.of(Material.GOLD_INGOT), Ingredient.of(Material.GOLD_INGOT), Ingredient.of(Material.GOLD_INGOT),
                    Ingredient.of(Material.GOLD_INGOT), Ingredient.of(Material.EGG), Ingredient.of(Material.GOLD_INGOT),
                    Ingredient.of(Material.GOLD_INGOT), Ingredient.of(Material.GOLD_INGOT), Ingredient.of(Material.GOLD_INGOT)};
            case DIAMOND -> new Ingredient[]{
                    Ingredient.of(Material.DIAMOND), Ingredient.of(Material.DIAMOND), Ingredient.of(Material.DIAMOND),
                    Ingredient.of(Material.DIAMOND), Ingredient.of(Material.EGG), Ingredient.of(Material.DIAMOND),
                    Ingredient.of(Material.DIAMOND), Ingredient.of(Material.DIAMOND), Ingredient.of(Material.DIAMOND)};
            case NETHERITE -> new Ingredient[]{
                    Ingredient.of(Material.NETHERITE_INGOT), Ingredient.of(Material.NETHERITE_INGOT), Ingredient.of(Material.NETHERITE_INGOT),
                    Ingredient.of(Material.NETHERITE_INGOT), Ingredient.of(Material.EGG), Ingredient.of(Material.NETHERITE_INGOT),
                    Ingredient.of(Material.NETHERITE_INGOT), Ingredient.of(Material.NETHERITE_INGOT), Ingredient.of(Material.NETHERITE_INGOT)};
        };
    }

    private String craftedPath(Tier tier) { return "crafted." + tier.id; }
    private boolean isCrafted(Tier tier) { return getConfig().getBoolean(craftedPath(tier), false); }
    private String locationKey(Location location) {
        return location.getWorld().getName() + "," + location.getBlockX() + "," + location.getBlockY() + "," + location.getBlockZ();
    }
    private boolean isForge(Location location) { return location.getWorld() != null && getConfig().getStringList("forges").contains(locationKey(location)); }

    private Inventory forgeMenu() {
        ForgeHolder holder = new ForgeHolder();
        Inventory inv = Bukkit.createInventory(holder, 45, ChatColor.DARK_PURPLE + "Boss Forge");
        holder.inventory = inv;
        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta paneMeta = filler.getItemMeta(); paneMeta.setDisplayName(" "); filler.setItemMeta(paneMeta);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        for (int slot : INPUT_SLOTS) inv.setItem(slot, null);
        inv.setItem(23, makeItem(Material.ARROW, "Recipe output", List.of(ChatColor.GRAY + "A matching egg appears on the right."), null, null));
        inv.setItem(OUTPUT_SLOT, makeItem(Material.BARRIER, "Place ingredients", List.of(ChatColor.GRAY + "Fill all nine slots with the exact pattern."), null, null));
        inv.setItem(44, makeItem(Material.BOOK, "Boss Forge instructions", List.of(
                ChatColor.GRAY + "Place all nine ingredients in the exact 3x3 pattern.",
                ChatColor.GRAY + "Each egg recipe can be crafted once across the entire server.",
                ChatColor.GRAY + "The recipe locks permanently after the first successful craft."), null, null));
        updateRecipeStatuses(inv);
        return inv;
    }

    private void updateRecipeStatuses(Inventory inv) {
        Material[] icons = {Material.OAK_SAPLING, Material.COBBLESTONE, Material.COPPER_INGOT,
                Material.IRON_INGOT, Material.GOLD_INGOT, Material.DIAMOND, Material.NETHERITE_INGOT};
        int slot = 36;
        for (Tier tier : Tier.values()) {
            boolean locked = isCrafted(tier);
            inv.setItem(slot++, makeItem(locked ? Material.BARRIER : icons[tier.ordinal()],
                    tier.bossName + " Egg — " + (locked ? "CRAFTED / LOCKED" : "AVAILABLE"),
                    List.of(locked ? ChatColor.RED + "This recipe has already been used globally."
                                    : ChatColor.GREEN + "This one-time recipe is still available."), null, null));
        }
    }

    private Tier matchingTier(Inventory inv) {
        for (Tier tier : Tier.values()) {
            Ingredient[] ingredients = recipeFor(tier);
            boolean match = true;
            for (int i = 0; i < INPUT_SLOTS.length; i++) {
                if (!ingredients[i].matches(inv.getItem(INPUT_SLOTS[i]))) { match = false; break; }
            }
            if (match) return tier;
        }
        return null;
    }

    private void updatePreview(Inventory inv) {
        if (!(inv.getHolder() instanceof ForgeHolder)) return;
        Tier tier = matchingTier(inv);
        if (tier == null) {
            inv.setItem(OUTPUT_SLOT, makeItem(Material.BARRIER, "Invalid recipe", List.of(ChatColor.GRAY + "Use the exact ingredient pattern."), null, null));
        } else if (isCrafted(tier)) {
            inv.setItem(OUTPUT_SLOT, makeItem(Material.BARRIER, tier.bossName + " Egg — LOCKED", List.of(
                    ChatColor.RED + "This recipe has already been crafted on this server."), null, null));
        } else {
            inv.setItem(OUTPUT_SLOT, eggItem(tier));
            inv.setItem(23, makeItem(Material.ARROW, "Ready to craft", List.of(ChatColor.GREEN + tier.bossName + " Egg"), null, null));
        }
    }

    private void giveOrDrop(Player player, ItemStack item, Location location) {
        Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item);
        for (ItemStack leftover : leftovers.values()) location.getWorld().dropItemNaturally(location, leftover);
    }

    private void craft(Player player, Inventory inv) {
        Tier tier = matchingTier(inv);
        if (tier == null) { player.sendMessage(ChatColor.RED + "The ingredients do not match a recipe."); return; }
        if (isCrafted(tier)) { player.sendMessage(ChatColor.RED + "That recipe has already been crafted globally."); updatePreview(inv); return; }
        for (int slot : INPUT_SLOTS) {
            ItemStack item = inv.getItem(slot);
            if (item == null || item.getAmount() < 1) return;
        }
        for (int slot : INPUT_SLOTS) {
            ItemStack item = inv.getItem(slot);
            item.setAmount(item.getAmount() - 1);
            if (item.getAmount() <= 0) inv.setItem(slot, null);
        }
        getConfig().set(craftedPath(tier), true);
        saveConfig(); // persist global lock before awarding the egg
        giveOrDrop(player, eggItem(tier), player.getLocation());
        player.sendMessage(ChatColor.GREEN + "Crafted " + tier.bossName + " Egg. This recipe is now locked for the whole server.");
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_AMETHYST_BLOCK_CHIME, 1f, 1.2f);
        updatePreview(inv);
        updateRecipeStatuses(inv);
    }

    @EventHandler
    public void onForgeRecipePreview(PrepareItemCraftEvent event) {
        if (!(event.getView().getPlayer() instanceof Player player)) return;
        if (hasTag(event.getInventory().getResult(), forgeKey, "boss_forge") && !supportsCustomFeatures(player)) {
            event.getInventory().setResult(new ItemStack(Material.AIR));
        }
    }

    @EventHandler
    public void onForgeRecipeCraft(CraftItemEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (hasTag(event.getCurrentItem(), forgeKey, "boss_forge") && !supportsCustomFeatures(player)) {
            event.setCancelled(true);
            player.sendMessage(ChatColor.RED + "The Boss Forge requires Minecraft 1.21.11 or newer.");
        }
    }

    @EventHandler
    public void onForgePlace(BlockPlaceEvent event) {
        if (!hasTag(event.getItemInHand(), forgeKey, "boss_forge")) return;
        List<String> list = getConfig().getStringList("forges");
        String key = locationKey(event.getBlockPlaced().getLocation());
        if (!list.contains(key)) list.add(key);
        getConfig().set("forges", list); saveConfig();
        event.getPlayer().sendMessage(ChatColor.LIGHT_PURPLE + "Boss Forge placed. Right-click it to craft boss eggs.");
    }

    @EventHandler
    public void onForgeBreak(BlockBreakEvent event) {
        Block block = event.getBlock();
        if (!isForge(block.getLocation())) return;
        event.setDropItems(false);
        List<String> list = getConfig().getStringList("forges");
        list.remove(locationKey(block.getLocation()));
        getConfig().set("forges", list); saveConfig();
        block.getWorld().dropItemNaturally(block.getLocation(), forgeItem());
    }

    @EventHandler
    public void onForgeInteract(PlayerInteractEvent event) {
        if (event.getHand() == null || !event.getHand().name().equals("HAND")) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK || event.getClickedBlock() == null) return;
        if (!isForge(event.getClickedBlock().getLocation())) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!supportsCustomFeatures(player)) { player.sendMessage(ChatColor.RED + "Boss Forge requires Minecraft 1.21.11 or newer."); return; }
        player.openInventory(forgeMenu());
    }

    @EventHandler
    public void onForgeClick(InventoryClickEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof ForgeHolder)) return;
        if (!(event.getWhoClicked() instanceof Player player)) return;
        int raw = event.getRawSlot();
        if (raw < 0) return;
        if (event.getClick().name().equals("DOUBLE_CLICK") || event.getAction().name().equals("COLLECT_TO_CURSOR")) {
            event.setCancelled(true);
            return;
        }
        if (raw >= event.getView().getTopInventory().getSize()) {
            if (event.isShiftClick()) event.setCancelled(true);
            return;
        }
        if (raw == OUTPUT_SLOT) { event.setCancelled(true); craft(player, event.getView().getTopInventory()); return; }
        if (!isInputSlot(raw)) { event.setCancelled(true); return; }
        Bukkit.getScheduler().runTask(this, () -> updatePreview(event.getView().getTopInventory()));
    }

    @EventHandler
    public void onForgeDrag(InventoryDragEvent event) {
        if (!(event.getView().getTopInventory().getHolder() instanceof ForgeHolder)) return;
        for (int raw : event.getRawSlots()) {
            if (raw < event.getView().getTopInventory().getSize() && !isInputSlot(raw)) { event.setCancelled(true); return; }
        }
        Bukkit.getScheduler().runTask(this, () -> updatePreview(event.getView().getTopInventory()));
    }

    @EventHandler
    public void onForgeClose(InventoryCloseEvent event) {
        if (!(event.getInventory().getHolder() instanceof ForgeHolder) || !(event.getPlayer() instanceof Player player)) return;
        for (int slot : INPUT_SLOTS) {
            ItemStack item = event.getInventory().getItem(slot);
            if (item != null && !item.getType().isAir()) {
                giveOrDrop(player, item.clone(), player.getLocation());
                event.getInventory().setItem(slot, null);
            }
        }
    }

    private boolean isInputSlot(int slot) {
        for (int input : INPUT_SLOTS) if (input == slot) return true;
        return false;
    }

    @EventHandler
    public void onEggUse(PlayerInteractEvent event) {
        if (event.getHand() == null || !event.getHand().name().equals("HAND")) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK && event.getAction() != Action.RIGHT_CLICK_AIR) return;
        Player player = event.getPlayer();
        ItemStack hand = player.getInventory().getItemInMainHand();
        String id = tag(hand, eggKey);
        Tier tier = id == null ? null : Tier.fromId(id);
        if (tier == null) return;
        if (event.getClickedBlock() != null && isForge(event.getClickedBlock().getLocation())) return;
        event.setCancelled(true);
        if (!supportsCustomFeatures(player)) { player.sendMessage(ChatColor.RED + "Boss events require Minecraft 1.21.11 or newer."); return; }

        Location spawn = spawnLocation(player, event.getClickedBlock(), event.getBlockFace());
        World world = spawn.getWorld();
        if (world == null) return;
        Villager guardian = world.spawn(spawn, Villager.class);
        guardian.setProfession(tier.profession);
        guardian.setVillagerLevel(5);
        guardian.setAI(false);
        guardian.setInvulnerable(true);
        guardian.setSilent(true);
        guardian.setPersistent(true);
        guardian.setCanPickupItems(false);
        guardian.setRemoveWhenFarAway(false);
        guardian.setCustomName(ChatColor.GOLD + "✦ " + tier.bossName + " ✦");
        guardian.setCustomNameVisible(true);
        PersistentDataContainer pdc = guardian.getPersistentDataContainer();
        pdc.set(bossKey, PersistentDataType.STRING, tier.id);
        pdc.set(progressKey, PersistentDataType.INTEGER, 0);
        pdc.set(topContributionKey, PersistentDataType.INTEGER, 0);

        ItemStack reduced = hand.clone(); reduced.setAmount(reduced.getAmount() - 1);
        player.getInventory().setItemInMainHand(reduced.getAmount() <= 0 ? new ItemStack(Material.AIR) : reduced);

        BossBar bar = createBossBar(tier, 0);
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (supportsCustomFeatures(online)) bar.addPlayer(online); else online.hideEntity(this, guardian);
        }
        activeBars.put(guardian.getUniqueId(), bar);
        world.spawnParticle(org.bukkit.Particle.HAPPY_VILLAGER, spawn.clone().add(0, 1.2, 0), 20, .5, .5, .5, .03);
        broadcastSupported(ChatColor.GOLD + "[BOSS EVENT] " + tier.bossName + " has appeared! "
                + ChatColor.YELLOW + "Location: " + world.getName() + " — X " + spawn.getBlockX()
                + ", Y " + spawn.getBlockY() + ", Z " + spawn.getBlockZ()
                + ChatColor.GRAY + " | Bring " + tier.required + " " + pretty(tier.supply) + " to complete the challenge.");
        player.sendMessage(ChatColor.GREEN + "Challenge started. Right-click the guardian while holding " + pretty(tier.supply) + " to contribute.");
    }

    private Location spawnLocation(Player player, Block clicked, BlockFace face) {
        Location loc;
        if (clicked != null) {
            loc = clicked.getRelative(face).getLocation().add(.5, 0, .5);
            if (!loc.getBlock().isPassable()) loc.add(0, 1, 0);
        } else {
            loc = player.getLocation().clone().add(player.getLocation().getDirection().normalize().multiply(3));
            loc.setY(player.getLocation().getY());
        }
        loc.setYaw(player.getLocation().getYaw()); loc.setPitch(0);
        return loc;
    }

    @EventHandler
    public void onGuardianDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Villager villager
                && villager.getPersistentDataContainer().has(bossKey, PersistentDataType.STRING)) event.setCancelled(true);
    }

    @EventHandler
    public void onGuardianInteract(PlayerInteractEntityEvent event) {
        if (!(event.getRightClicked() instanceof Villager boss) || event.getHand() == null || !event.getHand().name().equals("HAND")) return;
        String id = boss.getPersistentDataContainer().get(bossKey, PersistentDataType.STRING);
        Tier tier = id == null ? null : Tier.fromId(id);
        if (tier == null) return;
        event.setCancelled(true);
        Player player = event.getPlayer();
        if (!supportsCustomFeatures(player)) { player.sendMessage(ChatColor.RED + "Boss events require Minecraft 1.21.11 or newer."); return; }

        ItemStack held = player.getInventory().getItemInMainHand();
        int current = boss.getPersistentDataContainer().getOrDefault(progressKey, PersistentDataType.INTEGER, 0);
        if (held.getType() != tier.supply || held.getAmount() < 1) {
            player.sendMessage(ChatColor.YELLOW + "Bring " + pretty(tier.supply) + ". Progress: " + current + "/" + tier.required + ".");
            return;
        }
        if (current >= tier.required) return;
        int amount = Math.min(held.getAmount(), tier.required - current);
        ItemStack remaining = held.clone(); remaining.setAmount(remaining.getAmount() - amount);
        player.getInventory().setItemInMainHand(remaining.getAmount() <= 0 ? new ItemStack(Material.AIR) : remaining);
        int updated = current + amount;
        boss.getPersistentDataContainer().set(progressKey, PersistentDataType.INTEGER, updated);
        recordContribution(boss, player, amount);
        BossBar bar = activeBars.get(boss.getUniqueId());
        if (bar != null) {
            bar.setProgress(Math.min(1, updated / (double) tier.required));
            bar.setTitle(tier.bossName + " — supplies " + updated + "/" + tier.required);
        }
        player.sendMessage(ChatColor.GREEN + "Contributed " + amount + " " + pretty(tier.supply) + ". Progress: " + updated + "/" + tier.required + ".");
        if (updated >= tier.required) completeChallenge(boss, tier);
    }

    private void recordContribution(Villager boss, Player player, int amount) {
        String path = "events." + boss.getUniqueId() + ".contributions." + player.getUniqueId();
        int total = getConfig().getInt(path, 0) + amount;
        getConfig().set(path, total);
        int previousTop = boss.getPersistentDataContainer().getOrDefault(topContributionKey, PersistentDataType.INTEGER, 0);
        if (total > previousTop) {
            boss.getPersistentDataContainer().set(topContributionKey, PersistentDataType.INTEGER, total);
            boss.getPersistentDataContainer().set(topContributorKey, PersistentDataType.STRING, player.getUniqueId().toString());
        }
        saveConfig();
    }

    private void completeChallenge(Villager boss, Tier tier) {
        String uuidText = boss.getPersistentDataContainer().get(topContributorKey, PersistentDataType.STRING);
        UUID winnerId = null;
        if (uuidText != null) try { winnerId = UUID.fromString(uuidText); } catch (IllegalArgumentException ignored) { }
        int amount = boss.getPersistentDataContainer().getOrDefault(topContributionKey, PersistentDataType.INTEGER, 0);
        String winnerName = winnerId == null ? "No contributor" : getPlayerName(winnerId);
        if (winnerId != null) {
            Player winner = Bukkit.getPlayer(winnerId);
            if (winner != null && winner.isOnline()) giveOrDrop(winner, relicItem(tier), winner.getLocation());
            else {
                List<String> pending = getConfig().getStringList("pending-rewards." + winnerId);
                pending.add(tier.id);
                getConfig().set("pending-rewards." + winnerId, pending);
                saveConfig();
            }
        }
        broadcastSupported(ChatColor.GREEN + "[BOSS EVENT] " + tier.bossName + " challenge completed! "
                + ChatColor.AQUA + "Top contributor: " + winnerName + " (" + amount + " supplies). "
                + ChatColor.LIGHT_PURPLE + "Reward: " + tier.relicName + ".");
        boss.setCustomName(ChatColor.GREEN + "✓ " + tier.bossName + " — Challenge Complete");
        BossBar bar = activeBars.remove(boss.getUniqueId());
        if (bar != null) { bar.setProgress(1); bar.removeAll(); }
        getConfig().set("events." + boss.getUniqueId() + ".completed", true); saveConfig();
        Bukkit.getScheduler().runTaskLater(this, boss::remove, 100L);
    }

    private String getPlayerName(UUID uuid) {
        Player online = Bukkit.getPlayer(uuid);
        if (online != null) return online.getName();
        String name = Bukkit.getOfflinePlayer(uuid).getName();
        return name == null ? uuid.toString().substring(0, 8) : name;
    }

    private void deliverPending(Player player) {
        String path = "pending-rewards." + player.getUniqueId();
        List<String> rewards = getConfig().getStringList(path);
        if (rewards.isEmpty()) return;
        for (String id : new ArrayList<>(rewards)) {
            Tier tier = Tier.fromId(id);
            if (tier != null) giveOrDrop(player, relicItem(tier), player.getLocation());
        }
        getConfig().set(path, null); saveConfig();
        player.sendMessage(ChatColor.LIGHT_PURPLE + "Your Boss Forge challenge reward has been delivered.");
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        Bukkit.getScheduler().runTaskLater(this, () -> {
            if (!player.isOnline()) return;
            for (World world : Bukkit.getWorlds()) for (Entity entity : world.getEntities()) {
                if (entity instanceof Villager villager && villager.getPersistentDataContainer().has(bossKey, PersistentDataType.STRING)
                        && !supportsCustomFeatures(player)) player.hideEntity(this, entity);
            }
            if (supportsCustomFeatures(player)) {
                for (BossBar bar : activeBars.values()) bar.addPlayer(player);
                deliverPending(player);
            }
        }, 5L);
    }

    private boolean supportsCustomFeatures(Player player) {
        if (!Bukkit.getPluginManager().isPluginEnabled("ViaVersion")) return true;
        try {
            Class<?> via = Class.forName("com.viaversion.viaversion.api.Via");
            Object api = via.getMethod("getAPI").invoke(null);
            Class<?> apiType = Class.forName("com.viaversion.viaversion.api.ViaAPI");
            Method method = apiType.getMethod("getPlayerVersion", UUID.class);
            Object result = method.invoke(api, player.getUniqueId());
            return result instanceof Number number && number.intValue() >= MIN_PROTOCOL;
        } catch (ReflectiveOperationException | LinkageError ex) {
            getLogger().warning("Could not query ViaVersion for " + player.getName() + "; custom content hidden for this session.");
            return false;
        }
    }

    private void broadcastSupported(String message) {
        for (Player player : Bukkit.getOnlinePlayers()) if (supportsCustomFeatures(player)) player.sendMessage(message);
        getLogger().info(ChatColor.stripColor(message));
    }

    private String tag(ItemStack item, NamespacedKey key) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(key, PersistentDataType.STRING);
    }

    private boolean hasTag(ItemStack item, NamespacedKey key, String value) { return value.equals(tag(item, key)); }

    private static String pretty(Material material) {
        StringBuilder result = new StringBuilder();
        for (String part : material.name().toLowerCase(Locale.ROOT).split("_")) {
            if (result.length() > 0) result.append(' ');
            result.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
        }
        return result.toString();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(ChatColor.GOLD + "=== BossForge ===");
            sender.sendMessage(ChatColor.YELLOW + "/bossforge giveforge <player>");
            sender.sendMessage(ChatColor.YELLOW + "/bossforge giveegg <player> <tier>");
            sender.sendMessage(ChatColor.YELLOW + "/bossforge unlock <tier> | /bossforge reset | /bossforge claim");
            sender.sendMessage(ChatColor.GRAY + "All egg recipes use vanilla survival items and can be crafted once globally.");
            return true;
        }
        if (args[0].equalsIgnoreCase("claim")) {
            if (!(sender instanceof Player player)) { sender.sendMessage("Only a player can claim rewards."); return true; }
            if (!supportsCustomFeatures(player)) { player.sendMessage(ChatColor.RED + "BossForge rewards require Minecraft 1.21.11 or newer."); return true; }
            deliverPending(player); return true;
        }
        if (!sender.hasPermission("bossforge.admin")) { sender.sendMessage(ChatColor.RED + "No permission."); return true; }
        if (args[0].equalsIgnoreCase("giveforge") && args.length == 2) {
            Player target = Bukkit.getPlayerExact(args[1]);
            if (target == null) { sender.sendMessage(ChatColor.RED + "Player not found."); return true; }
            if (!supportsCustomFeatures(target)) { sender.sendMessage(ChatColor.RED + "That player needs Minecraft 1.21.11 or newer."); return true; }
            giveOrDrop(target, forgeItem(), target.getLocation());
            sender.sendMessage(ChatColor.GREEN + "Gave a Boss Forge to " + target.getName() + "."); return true;
        }
        if (args[0].equalsIgnoreCase("giveegg") && args.length == 3) {
            Player target = Bukkit.getPlayerExact(args[1]); Tier tier = Tier.fromId(args[2]);
            if (target == null || tier == null) { sender.sendMessage(ChatColor.RED + "Player not found or invalid tier."); return true; }
            if (!supportsCustomFeatures(target)) { sender.sendMessage(ChatColor.RED + "That player needs Minecraft 1.21.11 or newer."); return true; }
            giveOrDrop(target, eggItem(tier), target.getLocation());
            sender.sendMessage(ChatColor.GREEN + "Gave " + tier.bossName + " Egg. This admin command bypasses the global recipe lock."); return true;
        }
        if (args[0].equalsIgnoreCase("unlock") && args.length == 2) {
            Tier tier = Tier.fromId(args[1]);
            if (tier == null) { sender.sendMessage(ChatColor.RED + "Invalid tier."); return true; }
            getConfig().set(craftedPath(tier), false); saveConfig();
            sender.sendMessage(ChatColor.GREEN + tier.bossName + " Egg recipe unlocked."); return true;
        }
        if (args[0].equalsIgnoreCase("reset")) {
            for (Tier tier : Tier.values()) getConfig().set(craftedPath(tier), false);
            saveConfig(); sender.sendMessage(ChatColor.GREEN + "All seven egg recipes unlocked."); return true;
        }
        sender.sendMessage(ChatColor.RED + "Unknown command. Use /bossforge help.");
        return true;
    }
}
