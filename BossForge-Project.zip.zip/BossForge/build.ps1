$ErrorActionPreference = 'Stop'
$gradleCommand = Get-Command gradle -ErrorAction SilentlyContinue
if ($gradleCommand) {
    $gradle = $gradleCommand.Source
} else {
    $gradleVersion = '8.14.3'
    $installRoot = Join-Path $env:LOCALAPPDATA 'BossForge\gradle'
    $gradleHome = Join-Path $installRoot "gradle-$gradleVersion"
    $gradle = Join-Path $gradleHome 'bin\gradle.bat'
    if (-not (Test-Path $gradle)) {
        New-Item -ItemType Directory -Force -Path $installRoot | Out-Null
        $archive = Join-Path $installRoot "gradle-$gradleVersion-bin.zip"
        $url = "https://services.gradle.org/distributions/gradle-$gradleVersion-bin.zip"
        Write-Host "Downloading Gradle $gradleVersion..."
        Invoke-WebRequest -Uri $url -OutFile $archive
        Expand-Archive -Path $archive -DestinationPath $installRoot -Force
        Remove-Item $archive -Force
    }
}
Push-Location $PSScriptRoot
try {
    Write-Host 'Building BossForge for Paper 1.21.11...'
    & $gradle clean build
    if ($LASTEXITCODE -ne 0) { throw 'Gradle build failed. Read the error output above.' }
    Write-Host 'Build complete: build\libs\BossForge-1.1.0.jar'
} finally { Pop-Location }
