#!/usr/bin/env sh
set -eu
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle 8.14.3+ was not found. Install Gradle or use the Windows build.bat script." >&2
  exit 1
fi
gradle clean build
printf '\nBuilt: build/libs/BossForge-1.1.0.jar\n'
