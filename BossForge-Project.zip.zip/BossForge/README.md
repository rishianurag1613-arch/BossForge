# BossForge 1.1.0 — Paper 1.21.11

BossForge adds a special crafting station, seven globally one-time survival-craftable boss eggs, custom egg/forge item textures, server-wide location announcements, peaceful guardian supply challenges, and commemorative relic rewards.

**No custom recipe ingredients are required.** Every egg uses ordinary vanilla survival items. The guardians are peaceful, invulnerable villagers; players complete supply-delivery challenges rather than fighting them.

## Requirements

- Paper 1.21.11 (Java Edition)
- Java 21
- ViaVersion on the Paper server for per-player client-version detection
- ViaBackwards is optional and requires ViaVersion if older clients are allowed to connect
- The included resource pack for the custom egg and Boss Forge inventory textures

The plugin shows custom event features only to clients on Minecraft Java 1.21.11+ when ViaVersion is installed. The resource pack targets Java 1.21.11 (resource-pack format 75).

## Build

On Windows, run `build.bat` or `build.ps1`. The script uses Gradle if installed; otherwise it downloads Gradle 8.14.3. The first build also downloads the Paper API dependency, so the build computer needs internet access.

```text
build/libs/BossForge-1.1.0.jar
```

On Linux/macOS, install Gradle 8.14.3 or newer and run:

```sh
./build.sh
```

## Install the plugin

1. Build the project.
2. Copy `build/libs/BossForge-1.1.0.jar` into the Paper server's `plugins` folder.
3. Install ViaVersion. Install ViaBackwards too only if older client versions should be allowed to connect.
4. Restart the server.
5. Give an administrator a Boss Forge with `/bossforge giveforge <player>`.
6. Place the Boss Forge and right-click it to open the custom 3×3 crafting GUI.

## Install the custom resource pack

The separate `BossForge-Resource-Pack-1.21.11.zip` includes seven egg textures and a Boss Forge item icon.

- **Single player:** Options → Resource Packs → Open Pack Folder; place the ZIP in that folder and enable it.
- **Server:** host the ZIP at a direct HTTPS download URL and configure the server resource-pack URL and SHA-1 in `server.properties` or the hosting panel. The plugin does not host or automatically distribute the ZIP.

The placed Boss Forge block is still a Smithing Table block; the pack customizes the Boss Forge inventory item icon and all seven egg icons.

## Boss Forge recipe

Craft this in a normal crafting table:

```text
O  D  O
I  C  I
O  D  O
```

| Symbol | Vanilla item | Amount |
|---|---|---:|
| O | Obsidian | 4 |
| D | Diamond | 2 |
| I | Iron Ingot | 2 |
| C | Crafting Table | 1 |

Result: **1 Boss Forge** (a specially tagged Smithing Table item).

## The seven Boss Egg recipes

All seven eggs are crafted only inside the custom Boss Forge GUI. Put one item in each of the nine slots in the exact 3×3 pattern. The centre slot is always one ordinary chicken egg. There are no custom cores, custom tokens, or admin-only ingredients.

### 1. Wooden / Grove Guardian Egg

```text
L  P  L
P  E  P
L  P  L
```

- L = Oak Log ×4
- P = Oak Planks ×4
- E = Egg ×1

### 2. Stone / Granite Golem Egg

```text
C  C  C
C  E  C
C  C  C
```

- C = Cobblestone ×8
- E = Egg ×1

### 3. Copper / Storm Sentinel Egg

```text
I  B  I
I  E  B
I  B  B
```

- I = Copper Ingot ×4
- B = Copper Block ×4
- E = Egg ×1

### 4. Iron / Iron Warden Egg

```text
I  I  I
I  E  I
I  I  I
```

- I = Iron Ingot ×8
- E = Egg ×1

### 5. Golden / Sunforged Champion Egg

```text
G  G  G
G  E  G
G  G  G
```

- G = Gold Ingot ×8
- E = Egg ×1

### 6. Diamond / Crystal Colossus Egg

```text
D  D  D
D  E  D
D  D  D
```

- D = Diamond ×8
- E = Egg ×1

### 7. Netherite / Nether Tyrant Egg

```text
N  N  N
N  E  N
N  N  N
```

- N = Netherite Ingot ×8
- E = Egg ×1

## One-time crafting rule

- Each of the seven egg recipes can be crafted **once globally on the server**.
- The first successful craft consumes all nine ingredients and permanently locks that tier's recipe in `plugins/BossForge/config.yml`.
- The lock survives restarts.
- Each tier has its own lock; crafting one egg does not lock the other six.
- Admins can reopen one recipe with `/bossforge unlock <tier>` or reopen all seven with `/bossforge reset`.
- `/bossforge giveegg` is an admin override and does not change the global craft lock.

## Event mechanics

1. Right-click a block while holding a boss egg. The egg is consumed and its matching peaceful guardian appears.
2. The plugin broadcasts the world and XYZ coordinates to eligible clients (1.21.11+ when ViaVersion is installed).
3. A boss bar tracks the event's supply progress.
4. Players right-click the guardian while holding the requested supply item to contribute it.
5. The player with the highest total contribution receives the matching commemorative relic. Ties stay with the player who first reached the tied total.
6. If the winner is offline at completion, their relic is stored and delivered when they next join. `/bossforge claim` can also claim pending rewards.

| Egg tier | Event guardian | Supply target | Required amount | Relic |
|---|---|---|---:|---|
| Wooden | Grove Guardian | Oak Logs | 48 | Grove Crest |
| Stone | Granite Golem | Cobblestone | 48 | Stone Seal |
| Copper | Storm Sentinel | Copper Ingots | 32 | Copper Medallion |
| Iron | Iron Warden | Iron Ingots | 32 | Iron Emblem |
| Golden | Sunforged Champion | Gold Ingots | 24 | Golden Sigil |
| Diamond | Crystal Colossus | Diamonds | 12 | Diamond Star |
| Netherite | Nether Tyrant | Netherite Scraps | 6 | Ancient Crown |

## Commands

| Command | Permission | Purpose |
|---|---|---|
| `/bossforge help` | Everyone | Show help |
| `/bossforge claim` | Player | Claim pending relics |
| `/bossforge giveforge <player>` | `bossforge.admin` | Give a Boss Forge |
| `/bossforge giveegg <player> <tier>` | `bossforge.admin` | Give an egg (bypasses recipe lock) |
| `/bossforge unlock <tier>` | `bossforge.admin` | Unlock one egg recipe |
| `/bossforge reset` | `bossforge.admin` | Unlock all seven egg recipes |

Valid tiers: `wood`, `stone`, `copper`, `iron`, `gold`, `diamond`, `netherite`.

## Announcement

See `ANNOUNCEMENT.md` for a ready-to-post server announcement.
