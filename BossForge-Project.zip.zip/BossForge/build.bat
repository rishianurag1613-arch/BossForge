@echo off
setlocal
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0build.ps1"
if errorlevel 1 exit /b 1
echo.
echo Built: build\libs\BossForge-1.1.0.jar
