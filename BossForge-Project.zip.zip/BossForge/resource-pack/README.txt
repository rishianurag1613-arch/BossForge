BOSSFORGE RESOURCE PACK — Minecraft Java 1.21.11

This pack supplies the custom models and textures for the seven BossForge eggs and Boss Forge inventory item.

Install: Options > Resource Packs > Open Pack Folder, copy this ZIP into that folder, then enable it.

For a server-wide prompt, host this ZIP at a direct HTTPS download URL and configure your server resource-pack URL and SHA-1 in server.properties or your hosting panel. The plugin does not host or auto-distribute the pack by itself.

The Boss Forge block placed in the world remains a Smithing Table block; this pack customizes the Boss Forge item icon and all seven egg icons.
